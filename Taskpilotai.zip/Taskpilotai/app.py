import os
import json
import uuid
from pathlib import Path
from datetime import date, datetime, time, timedelta

import pandas as pd
import streamlit as st
from dotenv import load_dotenv
from google import genai

from task_manager import load_tasks, save_tasks


# =========================================================
# 1. CONFIGURATION
# =========================================================

load_dotenv()

st.set_page_config(
    page_title="TaskPilot AI",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

MODEL_NAME = "gemini-3.5-flash-lite"
API_KEY = os.getenv("GEMINI_API_KEY")
client = genai.Client(api_key=API_KEY) if API_KEY else None

BASE_DIR = Path(__file__).resolve().parent
HISTORY_FILE = BASE_DIR / "schedule_history.json"


# =========================================================
# 2. LIGHT & PROFESSIONAL DESIGN
# =========================================================

st.markdown(
    """
    <style>
    :root {
        --primary-blue: #3157D5;
        --soft-blue: #EEF2FF;
        --page-grey: #F7F8FC;
        --border-grey: #E5E7EB;
        --text-dark: #172033;
        --muted-text: #64748B;
    }

    .stApp {
        background: #F7F8FC;
        color: #172033;
    }

    .block-container {
        max-width: 1450px;
        padding-top: 1.5rem;
        padding-bottom: 2.5rem;
    }

    h1, h2, h3 {
        color: #172033;
        letter-spacing: -0.4px;
    }

    div[data-testid="stMetric"] {
        background: #FFFFFF;
        border: 1px solid #E5E7EB;
        border-radius: 14px;
        padding: 18px;
        box-shadow: 0 2px 8px rgba(20, 35, 80, 0.035);
    }

    div[data-testid="stMetricLabel"] {
        color: #64748B;
        font-size: 0.9rem;
    }

    div[data-testid="stMetricValue"] {
        color: #172033;
        font-size: 1.8rem;
        font-weight: 700;
    }

    div[data-testid="stVerticalBlockBorderWrapper"] {
        border-radius: 14px;
        border-color: #E5E7EB;
        background: #FFFFFF;
    }

    div.stButton > button,
    div.stDownloadButton > button {
        border-radius: 9px;
        min-height: 40px;
        font-weight: 600;
    }

    div.stButton > button[kind="primary"],
    div.stFormSubmitButton > button[kind="primary"] {
        background: #3157D5;
        border-color: #3157D5;
        color: #FFFFFF;
    }

    div[data-testid="stProgressBar"] {
        margin-top: 8px;
        margin-bottom: 8px;
    }

    section[data-testid="stSidebar"] {
        background: #FFFFFF;
        border-right: 1px solid #E5E7EB;
    }

    section[data-testid="stSidebar"] .block-container {
        padding-top: 1.5rem;
    }

    .tp-brand {
        font-size: 1.35rem;
        font-weight: 800;
        color: #3157D5;
        letter-spacing: -0.5px;
    }

    .tp-subtitle {
        color: #64748B;
        font-size: 0.92rem;
        margin-top: -8px;
    }

    .tp-eyebrow {
        color: #3157D5;
        text-transform: uppercase;
        font-size: 0.76rem;
        letter-spacing: 1.2px;
        font-weight: 700;
    }

    .tp-note {
        color: #64748B;
        font-size: 0.88rem;
    }

    @media (max-width: 768px) {
        .block-container {
            padding-left: 1rem;
            padding-right: 1rem;
        }
    }
    </style>
    """,
    unsafe_allow_html=True,
)


# =========================================================
# 3. SESSION STATE DEFAULTS
# =========================================================

SESSION_DEFAULTS = {
    "focused_ai_plan": None,
    "focused_plan_topic": "",
    "planner_subtasks": [],
    "planner_parent_name": "Planner task",
    "existing_subtasks": [],
    "existing_parent_name": "",
    "daily_schedule": None,
    "rescheduled_schedule": None,
    "navigation_page": "🏠 Dashboard",
}

for key, value in SESSION_DEFAULTS.items():
    if key not in st.session_state:
        st.session_state[key] = value


# =========================================================
# 4. SAFE SCHEDULE HISTORY STORAGE
# =========================================================

def load_history():
    """Read saved schedule history without silently replacing it."""

    if not HISTORY_FILE.exists():
        return {}

    try:
        with HISTORY_FILE.open("r", encoding="utf-8") as file:
            data = json.load(file)

        if not isinstance(data, dict):
            raise ValueError("Schedule history must be a JSON object.")

        return data

    except (OSError, json.JSONDecodeError, ValueError) as error:
        st.error(f"Unable to read schedule history: {error}")
        st.stop()


def save_history(history):
    """Save history atomically to reduce the risk of file corruption."""

    temp_file = HISTORY_FILE.with_suffix(".tmp")

    try:
        with temp_file.open("w", encoding="utf-8") as file:
            json.dump(history, file, indent=2, ensure_ascii=False)
            file.flush()
            os.fsync(file.fileno())

        os.replace(temp_file, HISTORY_FILE)

    except OSError:
        try:
            if temp_file.exists():
                temp_file.unlink()
        except OSError:
            pass

        raise


if "schedule_history" not in st.session_state:
    st.session_state.schedule_history = load_history()


# =========================================================
# 5. TASK DATA NORMALIZATION
# =========================================================

def parse_completed(value):
    """Interpret only explicit completed values as completed."""

    if isinstance(value, bool):
        return value

    if isinstance(value, (int, float)):
        return value == 1

    if isinstance(value, str):
        return value.strip().lower() in {
            "true", "1", "yes", "completed"
        }

    return False


def duration(task):
    try:
        value = float(task.get("hours", 1))
        return value if value > 0 else 1.0
    except (TypeError, ValueError):
        return 1.0


def priority_order(task):
    return {
        "High": 0,
        "Medium": 1,
        "Low": 2,
    }.get(task.get("priority", "Medium"), 1)


def normalize_tasks(existing):
    normalized = []

    for task in existing:
        if not isinstance(task, dict):
            continue

        priority = task.get("priority", "Medium")
        if priority not in ("High", "Medium", "Low"):
            priority = "Medium"

        normalized.append({
            **task,
            "id": str(task.get("id") or uuid.uuid4().hex),
            "name": str(task.get("name") or "Untitled task"),
            "priority": priority,
            "hours": duration(task),
            "completed": parse_completed(task.get("completed", False)),
        })

    return normalized


if "tasks" not in st.session_state:
    try:
        loaded_tasks = load_tasks()
        st.session_state.tasks = normalize_tasks(loaded_tasks)

        # Persist only if normalization changed the saved records.
        if st.session_state.tasks != loaded_tasks:
            save_tasks(st.session_state.tasks)

    except Exception as error:
        st.error(f"Unable to load saved tasks: {error}")
        st.stop()


def persist_tasks(updated):
    """Save dashboard tasks using the existing task manager."""

    save_tasks(updated)
    st.session_state.tasks = updated


def invalidate_schedules():
    """Remove generated previews after dashboard tasks change."""

    st.session_state.pop("daily_schedule", None)
    st.session_state.pop("rescheduled_schedule", None)


def update_task_status(task_id, widget_key):
    """Update one dashboard task without changing schedule history."""

    updated = []

    for task in st.session_state.tasks:
        if str(task["id"]) == str(task_id):
            updated.append({
                **task,
                "completed": parse_completed(
                    st.session_state.get(widget_key, False)
                ),
            })
        else:
            updated.append(task)

    try:
        persist_tasks(updated)
        invalidate_schedules()
    except Exception as error:
        st.error(f"Unable to save task status: {error}")


# =========================================================
# 6. SCHEDULE HISTORY HELPERS
# =========================================================

def is_activity_completed(value):
    """Support both modern activity dictionaries and legacy values."""

    if isinstance(value, dict):
        return parse_completed(value.get("completed", False))

    return parse_completed(value)


def get_history_activities(record):
    """Return a safe activity dictionary from a history record."""

    if not isinstance(record, dict):
        return {}

    activities = record.get("activities", {})
    return activities if isinstance(activities, dict) else {}


def get_saved_activity_status(record, activity_id):
    activities = get_history_activities(record)
    return is_activity_completed(activities.get(str(activity_id), False))


# =========================================================
# 7. GEMINI HELPER
# =========================================================

def gemini_text(prompt, json_mode=False):
    if client is None:
        raise ValueError(
            "Gemini API key is missing. Check GEMINI_API_KEY "
            "in your existing .env file."
        )

    config = (
        {"response_mime_type": "application/json"}
        if json_mode
        else None
    )

    response = client.models.generate_content(
        model=MODEL_NAME,
        contents=prompt,
        config=config,
    )

    if not response.text:
        raise ValueError("Gemini returned an empty response.")

    return response.text


# =========================================================
# 8. AI TASK BREAKDOWN
# =========================================================

def generate_subtasks(task_name, topic, level, goal, hours):
    prompt = f"""
You are TaskPilot AI, a practical task breakdown assistant.

Break the task into 3 to 7 actionable subtasks.

Task: {task_name}
Topic: {topic}
Skill level: {level}
Goal: {goal}
Available hours: {hours}

Return valid JSON only:
{{
  "subtasks": [
    {{
      "name": "Review important concepts",
      "priority": "High",
      "hours": 0.5
    }}
  ]
}}

Requirements:
- Each subtask must be actionable.
- Priority must be High, Medium, or Low.
- Duration must be greater than 0 and no more than 12 hours.
- Stay focused on the specified topic.
"""

    data = json.loads(gemini_text(prompt, json_mode=True))
    results = []

    for item in data.get("subtasks", []):
        if not isinstance(item, dict):
            continue

        name = str(item.get("name", "")).strip()
        priority = item.get("priority", "Medium")

        try:
            hours_value = float(item.get("hours", 0))
        except (TypeError, ValueError):
            continue

        if not name or not 0 < hours_value <= 12:
            continue

        if priority not in ("High", "Medium", "Low"):
            priority = "Medium"

        results.append({
            "name": name,
            "priority": priority,
            "hours": hours_value,
        })

    if not results:
        raise ValueError("Gemini did not return any valid subtasks.")

    return results


# =========================================================
# 9. AI TASK ORDERING
# =========================================================

def order_tasks_with_ai(tasks):
    prompt_tasks = [
        {
            "id": str(task["id"]),
            "name": task["name"],
            "priority": task.get("priority", "Medium"),
            "hours": duration(task),
        }
        for task in tasks
    ]

    prompt = f"""
Order these tasks for a sensible daily work schedule.

Consider priority, duration, and logical dependencies.

Tasks:
{json.dumps(prompt_tasks, ensure_ascii=False)}

Return JSON only:
{{"ordered_task_ids": ["id1", "id2"]}}

Use only supplied IDs. Do not invent IDs.
"""

    data = json.loads(gemini_text(prompt, json_mode=True))
    ids = data.get("ordered_task_ids", [])

    by_id = {str(task["id"]): task for task in tasks}
    ordered = []
    seen = set()

    for task_id in ids:
        task_id = str(task_id)

        if task_id in by_id and task_id not in seen:
            ordered.append(by_id[task_id])
            seen.add(task_id)

    remaining = [
        task for task in tasks
        if str(task["id"]) not in seen
    ]

    remaining.sort(
        key=lambda task: (priority_order(task), -duration(task))
    )

    return ordered + remaining


# =========================================================
# 10. SUBTASK MANAGEMENT
# =========================================================

def add_subtasks(subtasks, selected_indices, parent_name):
    if not selected_indices:
        st.warning("Select at least one subtask.")
        return

    new_tasks = []

    for index in selected_indices:
        if not 0 <= index < len(subtasks):
            continue

        item = subtasks[index]

        new_tasks.append({
            "id": uuid.uuid4().hex,
            "name": item["name"],
            "priority": item["priority"],
            "hours": item["hours"],
            "completed": False,
            "parent_task": parent_name,
        })

    if not new_tasks:
        return

    try:
        persist_tasks(st.session_state.tasks + new_tasks)
        invalidate_schedules()
        st.success(f"Added {len(new_tasks)} subtask(s).")
        st.rerun()
    except Exception as error:
        st.error(f"Unable to save subtasks: {error}")


def subtask_review(state_key, parent_name, form_key):
    items = st.session_state.get(state_key, [])

    if not items:
        return

    st.markdown("#### Review generated subtasks")
    st.caption("Choose which subtasks to add to My Tasks.")

    with st.form(form_key):
        selected = []

        for index, item in enumerate(items):
            checked = st.checkbox(
                f"{item['name']} — {item['hours']:g} hour(s) "
                f"— {item['priority']} priority",
                value=True,
                key=f"{form_key}_{index}",
            )

            if checked:
                selected.append(index)

        if st.form_submit_button(
            "➕ Add Selected Subtasks",
            type="primary",
        ):
            add_subtasks(items, selected, parent_name)


# =========================================================
# 11. SCHEDULING ENGINE
# =========================================================

def build_timetable(tasks_to_schedule, start_time, end_time, break_minutes):
    start_dt = datetime.combine(date.today(), start_time)
    end_dt = datetime.combine(date.today(), end_time)

    if end_dt <= start_dt:
        raise ValueError("End time must be later than start time.")

    current = start_dt
    scheduled = []
    carry_forward = []

    for task in tasks_to_schedule:
        task_hours = duration(task)
        task_end = current + timedelta(hours=task_hours)

        if task_end > end_dt:
            carry_forward.append(task)
            continue

        scheduled.append({
            "id": str(task["id"]),
            "name": task["name"],
            "priority": task.get("priority", "Medium"),
            "hours": task_hours,
            "start_dt": current,
            "end_dt": task_end,
        })

        current = task_end + timedelta(minutes=break_minutes)

    return scheduled, carry_forward


def show_timetable(schedule, title):
    st.subheader(title)

    if schedule.get("warning"):
        st.warning(schedule["warning"])

    st.caption(
        f"🕒 {schedule['start']} – {schedule['end']} "
        f"· {schedule['break_minutes']}-minute breaks"
    )

    items = schedule.get("scheduled", [])
    carry_forward = schedule.get("carry_forward", [])

    if not items:
        st.info("No tasks fit in this time window.")
    else:
        rows = []

        for index, item in enumerate(items):
            rows.append({
                "Time": (
                    f"{item['start_dt'].strftime('%I:%M %p')} – "
                    f"{item['end_dt'].strftime('%I:%M %p')}"
                ),
                "Activity": item["name"],
                "Priority": item["priority"],
                "Duration": f"{item['hours']:g} hour(s)",
            })

            if index < len(items) - 1:
                next_start = items[index + 1]["start_dt"]
                break_start = item["end_dt"]

                if next_start > break_start:
                    minutes = int(
                        (next_start - break_start).total_seconds() / 60
                    )

                    rows.append({
                        "Time": (
                            f"{break_start.strftime('%I:%M %p')} – "
                            f"{next_start.strftime('%I:%M %p')}"
                        ),
                        "Activity": "☕ Break",
                        "Priority": "—",
                        "Duration": f"{minutes} minutes",
                    })

        st.dataframe(
            pd.DataFrame(rows),
            use_container_width=True,
            hide_index=True,
        )

    c1, c2, c3 = st.columns(3)
    c1.metric("Tasks Scheduled", len(items))
    c2.metric(
        "Planned Task Time",
        f"{sum(item['hours'] for item in items):g} h",
    )
    c3.metric("Carry-forward Tasks", len(carry_forward))

    if carry_forward:
        with st.expander("📌 Tasks that do not fit this time window"):
            for task in carry_forward:
                st.write(
                    f"- {task['name']} — "
                    f"{task.get('priority', 'Medium')} priority — "
                    f"{duration(task):g} hour(s)"
                )


# =========================================================
# END OF PART 1
# Part 2 adds sidebar navigation, Dashboard, and My Tasks.
# =========================================================
# =========================================================
# 12. SIDEBAR NAVIGATION
# =========================================================

PAGES = [
    "🏠 Dashboard",
    "✅ My Tasks",
    "📅 Daily Scheduler",
    "🔄 Smart Rescheduling",
    "🧠 AI Planner",
    "🧩 Task Breakdown",
    "📚 Daily History",
    "📊 Monthly Insights",
]

with st.sidebar:
    st.markdown(
        '<div class="tp-brand">🤖 TaskPilot AI</div>',
        unsafe_allow_html=True,
    )
    st.caption("Your personal productivity workspace")
    st.divider()

    selected_page = st.radio(
        "WORKSPACE",
        PAGES,
        key="navigation_page",
        label_visibility="visible",
    )

    st.divider()

    sidebar_tasks = st.session_state.tasks
    sidebar_total = len(sidebar_tasks)
    sidebar_completed = sum(
        1 for task in sidebar_tasks
        if parse_completed(task.get("completed", False))
    )
    sidebar_pending = sidebar_total - sidebar_completed

    st.markdown("**Your task overview**")
    m1, m2 = st.columns(2)
    m1.metric("Pending", sidebar_pending)
    m2.metric("Completed", sidebar_completed)

    sidebar_progress = (
        sidebar_completed / sidebar_total
        if sidebar_total else 0.0
    )
    st.progress(sidebar_progress)

    st.caption(
        f"{sidebar_progress:.0%} of dashboard tasks completed"
    )

    st.divider()
    st.caption("✨ Plan smarter. Focus better.")


# =========================================================
# 13. SHARED PAGE HEADER
# =========================================================

PAGE_DETAILS = {
    "🏠 Dashboard": (
        "Your productivity at a glance",
        "Monitor your tasks, completion progress, and next actions.",
    ),
    "✅ My Tasks": (
        "Manage your tasks",
        "Add, organize, prioritize, complete, and delete tasks.",
    ),
    "📅 Daily Scheduler": (
        "Build your daily timetable",
        "Turn pending dashboard tasks into a practical schedule.",
    ),
    "🔄 Smart Rescheduling": (
        "Adapt your plan",
        "Reorganize unfinished work when your availability changes.",
    ),
    "🧠 AI Planner": (
        "Create a focused learning plan",
        "Turn a learning goal into a structured plan using Gemini.",
    ),
    "🧩 Task Breakdown": (
        "Break big tasks into smaller steps",
        "Generate actionable subtasks and select the ones to keep.",
    ),
    "📚 Daily History": (
        "Review your saved activity history",
        "Explore previous daily schedule completion records.",
    ),
    "📊 Monthly Insights": (
        "Understand your productivity",
        "Analyze saved schedule activity trends by month.",
    ),
}

page_title, page_subtitle = PAGE_DETAILS[selected_page]

st.markdown(
    f'<div class="tp-eyebrow">TASKPILOT AI / WORKSPACE</div>',
    unsafe_allow_html=True,
)
st.title(page_title)
st.markdown(
    f'<div class="tp-subtitle">{page_subtitle}</div>',
    unsafe_allow_html=True,
)
st.write("")


# =========================================================
# 14. DASHBOARD PAGE
# =========================================================

if selected_page == "🏠 Dashboard":

    tasks = st.session_state.tasks
    total = len(tasks)

    completed = sum(
        1 for task in tasks
        if parse_completed(task.get("completed", False))
    )
    pending = total - completed

    completion_rate = completed / total if total else 0.0

    # KPI cards
    col1, col2, col3, col4 = st.columns(4)

    col1.metric("📋 Total Tasks", total)
    col2.metric("⏳ Pending", pending)
    col3.metric("✅ Completed", completed)
    col4.metric("📈 Completion", f"{completion_rate:.0%}")

    st.write("")

    # Progress panel
    with st.container(border=True):
        st.subheader("Overall Progress")

        progress_col, percentage_col = st.columns([4, 1])

        with progress_col:
            st.progress(completion_rate)

        with percentage_col:
            st.metric("Progress", f"{completion_rate:.0%}")

        if total == 0:
            st.info(
                "Welcome to TaskPilot AI! Add your first task "
                "to start tracking your productivity."
            )
        elif pending == 0:
            st.success("🎉 Fantastic! All dashboard tasks are completed.")
        else:
            st.write(
                f"You have **{pending} pending task(s)** remaining."
            )

    # Quick navigation
    st.subheader("Quick Actions")

    quick1, quick2, quick3 = st.columns(3)

    with quick1:
        with st.container(border=True):
            st.markdown("### ✅ My Tasks")
            st.write("Create tasks and manage your priorities.")
            if st.button(
                "Manage Tasks →",
                key="dashboard_manage_tasks",
                use_container_width=True,
            ):
                st.session_state.navigation_page = "✅ My Tasks"
                st.rerun()

    with quick2:
        with st.container(border=True):
            st.markdown("### 📅 Daily Scheduler")
            st.write("Plan your available time for pending tasks.")
            if st.button(
                "Create Schedule →",
                key="dashboard_create_schedule",
                use_container_width=True,
            ):
                st.session_state.navigation_page = "📅 Daily Scheduler"
                st.rerun()

    with quick3:
        with st.container(border=True):
            st.markdown("### 🧠 AI Planner")
            st.write("Build a focused plan for a learning goal.")
            if st.button(
                "Open AI Planner →",
                key="dashboard_open_planner",
                use_container_width=True,
            ):
                st.session_state.navigation_page = "🧠 AI Planner"
                st.rerun()

    # Pending task preview
    st.subheader("Your Pending Tasks")

    pending_tasks = [
        task for task in tasks
        if not parse_completed(task.get("completed", False))
    ]
    pending_tasks.sort(
        key=lambda task: (
            priority_order(task),
            task["name"].lower(),
        )
    )

    if not pending_tasks:
        st.success("No pending tasks. You're all caught up!")
    else:
        preview_tasks = pending_tasks[:5]

        for task in preview_tasks:
            priority = task.get("priority", "Medium")
            priority_icon = {
                "High": "🔴",
                "Medium": "🟡",
                "Low": "🟢",
            }.get(priority, "⚪")

            with st.container(border=True):
                task_col, priority_col, duration_col = st.columns(
                    [4, 2, 1],
                    vertical_alignment="center",
                )

                with task_col:
                    st.markdown(f"**{task['name']}**")

                    if task.get("parent_task"):
                        st.caption(
                            f"Subtask of: {task['parent_task']}"
                        )

                with priority_col:
                    st.write(f"{priority_icon} {priority}")

                with duration_col:
                    st.write(f"{duration(task):g} h")

        if len(pending_tasks) > 5:
            st.caption(
                f"Showing 5 of {len(pending_tasks)} pending tasks."
            )

        if st.button(
            "View All Tasks →",
            key="dashboard_view_all_tasks",
        ):
            st.session_state.navigation_page = "✅ My Tasks"
            st.rerun()

    # Schedule summary is deliberately separate from task completion.
    st.subheader("Today's Schedule")

    current_schedule = st.session_state.get("daily_schedule")

    if not current_schedule:
        st.info(
            "You haven't generated a timetable in this session yet. "
            "Open Daily Scheduler to create one."
        )
    else:
        schedule_items = current_schedule.get("scheduled", [])
        schedule_date = current_schedule.get(
            "date",
            date.today().isoformat(),
        )

        saved_record = st.session_state.schedule_history.get(
            schedule_date,
            {},
        )

        saved_activities = get_history_activities(saved_record)

        schedule_completed = sum(
            1 for item in schedule_items
            if is_activity_completed(
                st.session_state.get(
                    f"schedule_{schedule_date}_{item['id']}",
                    saved_activities.get(str(item["id"]), False),
                )
            )
        )

        schedule_total = len(schedule_items)
        schedule_pending = schedule_total - schedule_completed

        sc1, sc2, sc3 = st.columns(3)
        sc1.metric("Scheduled Activities", schedule_total)
        sc2.metric("Activities Completed", schedule_completed)
        sc3.metric("Activities Remaining", schedule_pending)

        st.caption(
            "These numbers describe your daily schedule, not your "
            "overall dashboard task completion."
        )

        if st.button(
            "Open Daily Scheduler →",
            key="dashboard_open_daily_schedule",
        ):
            st.session_state.navigation_page = "📅 Daily Scheduler"
            st.rerun()


# =========================================================
# 15. MY TASKS PAGE
# =========================================================

elif selected_page == "✅ My Tasks":

    st.subheader("➕ Add a New Task")

    with st.container(border=True):
        with st.form("add_task_form", clear_on_submit=True):

            task_name = st.text_input(
                "Task name",
                placeholder="Example: Practice binary search",
            )

            col1, col2 = st.columns(2)

            with col1:
                task_priority = st.selectbox(
                    "Priority",
                    ["High", "Medium", "Low"],
                    index=1,
                )

            with col2:
                task_hours = st.number_input(
                    "Estimated duration (hours)",
                    min_value=0.5,
                    max_value=12.0,
                    value=1.0,
                    step=0.5,
                )

            add_clicked = st.form_submit_button(
                "➕ Add Task",
                type="primary",
                use_container_width=True,
            )

        if add_clicked:
            if not task_name.strip():
                st.warning("Please enter a task name.")
            else:
                new_task = {
                    "id": uuid.uuid4().hex,
                    "name": task_name.strip(),
                    "priority": task_priority,
                    "hours": float(task_hours),
                    "completed": False,
                }

                try:
                    persist_tasks(
                        st.session_state.tasks + [new_task]
                    )
                    invalidate_schedules()
                    st.success("Task added successfully!")
                    st.rerun()

                except Exception as error:
                    st.error(f"Unable to add task: {error}")

    st.divider()

    # Current task statistics
    tasks = st.session_state.tasks
    total = len(tasks)

    completed = sum(
        1 for task in tasks
        if parse_completed(task.get("completed", False))
    )
    pending = total - completed

    col1, col2, col3 = st.columns(3)
    col1.metric("Total Tasks", total)
    col2.metric("Pending", pending)
    col3.metric("Completed", completed)

    st.subheader("📝 Your Tasks")

    if not tasks:
        st.info("No tasks yet. Use the form above to add your first task.")

    else:
        filter_col, sort_col = st.columns(2)

        with filter_col:
            task_filter = st.selectbox(
                "Filter tasks",
                [
                    "All tasks",
                    "Pending only",
                    "Completed only",
                ],
                key="task_list_filter",
            )

        with sort_col:
            task_sort = st.selectbox(
                "Sort tasks",
                [
                    "Default order",
                    "Highest priority",
                    "Longest duration",
                    "Shortest duration",
                    "Task name",
                ],
                key="task_list_sort",
            )

        visible_tasks = list(tasks)

        if task_filter == "Pending only":
            visible_tasks = [
                task for task in visible_tasks
                if not parse_completed(task.get("completed", False))
            ]

        elif task_filter == "Completed only":
            visible_tasks = [
                task for task in visible_tasks
                if parse_completed(task.get("completed", False))
            ]

        if task_sort == "Highest priority":
            visible_tasks.sort(
                key=lambda task: (
                    priority_order(task),
                    task["name"].lower(),
                )
            )

        elif task_sort == "Longest duration":
            visible_tasks.sort(
                key=duration,
                reverse=True,
            )

        elif task_sort == "Shortest duration":
            visible_tasks.sort(key=duration)

        elif task_sort == "Task name":
            visible_tasks.sort(
                key=lambda task: task["name"].lower()
            )

        st.caption(f"Showing {len(visible_tasks)} task(s).")

        if not visible_tasks:
            st.info("No tasks match the selected filter.")

        for task in visible_tasks:
            task_id = str(task["id"])
            widget_key = f"dashboard_done_{task_id}"
            is_done = parse_completed(task.get("completed", False))

            # Initialize a checkbox from saved task status.
            if widget_key not in st.session_state:
                st.session_state[widget_key] = is_done

            with st.container(border=True):
                task_col, priority_col, duration_col, delete_col = (
                    st.columns(
                        [4, 1.5, 1.2, 0.7],
                        vertical_alignment="center",
                    )
                )

                with task_col:
                    st.checkbox(
                        task["name"],
                        key=widget_key,
                        on_change=update_task_status,
                        args=(task_id, widget_key),
                    )

                    if task.get("parent_task"):
                        st.caption(
                            f"↳ Subtask of: {task['parent_task']}"
                        )

                    st.caption(
                        "✅ Completed" if is_done else "⏳ Pending"
                    )

                with priority_col:
                    priority = task.get("priority", "Medium")
                    priority_icon = {
                        "High": "🔴",
                        "Medium": "🟡",
                        "Low": "🟢",
                    }.get(priority, "⚪")

                    st.write(f"{priority_icon} {priority}")

                with duration_col:
                    st.write(f"⏱️ {duration(task):g} h")

                with delete_col:
                    if st.button(
                        "🗑️",
                        key=f"delete_{task_id}",
                        help=f"Delete {task['name']}",
                        use_container_width=True,
                    ):
                        try:
                            updated = [
                                item
                                for item in st.session_state.tasks
                                if str(item["id"]) != task_id
                            ]

                            persist_tasks(updated)
                            st.session_state.pop(widget_key, None)
                            invalidate_schedules()
                            st.rerun()

                        except Exception as error:
                            st.error(f"Unable to delete task: {error}")


# =========================================================
# END OF PART 2
# Part 3 adds Daily Scheduler and Smart Rescheduling.
# =========================================================
# =========================================================
# 16. DAILY SCHEDULER PAGE
# =========================================================

elif selected_page == "📅 Daily Scheduler":

    st.subheader("⏰ Plan your available time")

    st.write(
        "Create a timetable from pending dashboard tasks. "
        "Generating a schedule never marks tasks as completed."
    )

    with st.container(border=True):
        with st.form("scheduler_settings"):

            col1, col2 = st.columns(2)

            with col1:
                start_time = st.time_input(
                    "Start time",
                    value=time(18, 30),
                    key="scheduler_start",
                )

            with col2:
                end_time = st.time_input(
                    "End time",
                    value=time(22, 0),
                    key="scheduler_end",
                )

            break_minutes = st.selectbox(
                "Break between tasks",
                [5, 10, 15, 20, 30],
                index=2,
                format_func=lambda value: f"{value} minutes",
                key="scheduler_break",
            )

            scheduling_mode = st.radio(
                "Scheduling mode",
                [
                    "AI-powered (Gemini)",
                    "Priority-based (no AI)",
                ],
                key="scheduler_mode",
            )

            st.write("**Include these priorities:**")

            p1, p2, p3 = st.columns(3)

            with p1:
                include_high = st.checkbox(
                    "🔴 High",
                    value=True,
                    key="scheduler_high",
                )

            with p2:
                include_medium = st.checkbox(
                    "🟡 Medium",
                    value=True,
                    key="scheduler_medium",
                )

            with p3:
                include_low = st.checkbox(
                    "🟢 Low",
                    value=True,
                    key="scheduler_low",
                )

            generate = st.form_submit_button(
                "✨ Generate Daily Schedule",
                type="primary",
                use_container_width=True,
            )

    if generate:
        if end_time <= start_time:
            st.error("End time must be later than start time.")

        else:
            allowed = set()

            if include_high:
                allowed.add("High")
            if include_medium:
                allowed.add("Medium")
            if include_low:
                allowed.add("Low")

            eligible = [
                task for task in st.session_state.tasks
                if not parse_completed(task.get("completed", False))
                and task.get("priority", "Medium") in allowed
            ]

            warning = None

            if (
                scheduling_mode == "AI-powered (Gemini)"
                and eligible
            ):
                try:
                    with st.spinner(
                        "Gemini is organizing your tasks..."
                    ):
                        ordered = order_tasks_with_ai(eligible)

                except Exception as error:
                    ordered = sorted(
                        eligible,
                        key=lambda task: (
                            priority_order(task),
                            -duration(task),
                        ),
                    )
                    warning = (
                        "Gemini was unavailable, so priority-based "
                        "ordering was used. "
                        f"Details: {error}"
                    )

            else:
                ordered = sorted(
                    eligible,
                    key=lambda task: (
                        priority_order(task),
                        -duration(task),
                    ),
                )

            try:
                scheduled, carry_forward = build_timetable(
                    ordered,
                    start_time,
                    end_time,
                    break_minutes,
                )

                # Replace the previous preview only after a valid
                # schedule has been generated.
                st.session_state.daily_schedule = {
                    "date": date.today().isoformat(),
                    "scheduled": scheduled,
                    "carry_forward": carry_forward,
                    "start": start_time.strftime("%I:%M %p"),
                    "end": end_time.strftime("%I:%M %p"),
                    "break_minutes": break_minutes,
                    "warning": warning,
                    "generated_at": datetime.now().isoformat(
                        timespec="minutes"
                    ),
                }

                st.session_state.pop("rescheduled_schedule", None)

            except Exception as error:
                st.error(f"Unable to generate the schedule: {error}")

    # Keep the generated schedule visible across reruns.
    schedule = st.session_state.get("daily_schedule")

    if schedule:
        st.divider()
        show_timetable(schedule, "🗓️ Your Daily Timetable")

        schedule_date = schedule.get(
            "date",
            date.today().isoformat(),
        )

        st.subheader("✅ Track your daily activities")

        st.caption(
            "These checkboxes track schedule activities separately "
            "from the completion status of your dashboard tasks."
        )

        history_record = st.session_state.schedule_history.get(
            schedule_date,
            {},
        )
        saved_activities = get_history_activities(history_record)
        activities = schedule.get("scheduled", [])

        if not activities:
            st.info(
                "No activities fit this timetable. Add pending tasks "
                "or extend your available time."
            )

        for item in activities:
            activity_id = str(item["id"])
            widget_key = f"schedule_{schedule_date}_{activity_id}"

            # Initialize only if this checkbox has no current
            # session value. Do not overwrite unsaved user changes.
            if widget_key not in st.session_state:
                st.session_state[widget_key] = is_activity_completed(
                    saved_activities.get(activity_id, False)
                )

            with st.container(border=True):
                st.checkbox(
                    (
                        f"{item['start_dt'].strftime('%I:%M %p')} – "
                        f"{item['end_dt'].strftime('%I:%M %p')}  |  "
                        f"{item['name']}"
                    ),
                    key=widget_key,
                )

                st.caption(
                    f"{item.get('priority', 'Medium')} priority · "
                    f"{item.get('hours', 1):g} hour(s)"
                )

        total_activities = len(activities)

        completed_activities = sum(
            bool(
                st.session_state.get(
                    f"schedule_{schedule_date}_{item['id']}",
                    False,
                )
            )
            for item in activities
        )

        pending_activities = total_activities - completed_activities

        completion_rate = (
            completed_activities / total_activities
            if total_activities else 0.0
        )

        c1, c2, c3 = st.columns(3)
        c1.metric("Scheduled", total_activities)
        c2.metric("Completed", completed_activities)
        c3.metric("Remaining", pending_activities)

        st.progress(completion_rate)
        st.caption(f"Schedule completion: {completion_rate:.0%}")

        if st.button(
            "💾 Save Daily Completion",
            type="primary",
            key=f"save_daily_{schedule_date}",
            use_container_width=True,
        ):
            new_history = dict(st.session_state.schedule_history)

            old_record = new_history.get(
                schedule_date,
                {"activities": {}, "updated_at": None},
            )

            statuses = dict(get_history_activities(old_record))

            # Preserve existing records and update activities in
            # the current schedule.
            for item in activities:
                activity_id = str(item["id"])
                widget_key = f"schedule_{schedule_date}_{activity_id}"

                statuses[activity_id] = {
                    "completed": bool(
                        st.session_state.get(widget_key, False)
                    ),
                    "name": item["name"],
                    "priority": item.get("priority", "Medium"),
                    "hours": item.get("hours", 1.0),
                }

            new_history[schedule_date] = {
                "activities": statuses,
                "updated_at": datetime.now().isoformat(
                    timespec="seconds"
                ),
            }

            try:
                save_history(new_history)
                st.session_state.schedule_history = new_history

                st.success("Daily completion saved successfully!")
                st.rerun()

            except OSError as error:
                st.error(
                    f"Unable to save daily completion: {error}"
                )

    else:
        st.info(
            "Configure your available time above and generate "
            "a timetable to get started."
        )


# =========================================================
# 17. SMART RESCHEDULING PAGE
# =========================================================

elif selected_page == "🔄 Smart Rescheduling":

    st.subheader("🔄 Replan your unfinished activities")

    st.write(
        "Create a new timetable for remaining work. Completed "
        "schedule activities are excluded, and the new timetable "
        "is only applied when you confirm it."
    )

    original_schedule = st.session_state.get("daily_schedule")

    if not original_schedule:
        st.info(
            "Generate a daily timetable first. Then return here "
            "to reorganize your unfinished activities."
        )

    else:
        original_date = original_schedule.get(
            "date",
            date.today().isoformat(),
        )

        saved_record = st.session_state.schedule_history.get(
            original_date,
            {},
        )
        saved_statuses = get_history_activities(saved_record)

        with st.container(border=True):
            st.markdown("### ⏰ Your remaining availability")

            with st.form("reschedule_settings"):

                col1, col2 = st.columns(2)

                with col1:
                    new_start = st.time_input(
                        "New start time",
                        value=time(20, 0),
                        key="reschedule_start",
                    )

                with col2:
                    new_end = st.time_input(
                        "New end time",
                        value=time(22, 0),
                        key="reschedule_end",
                    )

                new_break = st.selectbox(
                    "Break between tasks",
                    [5, 10, 15, 20, 30],
                    index=2,
                    format_func=lambda value: f"{value} minutes",
                    key="reschedule_break",
                )

                reschedule_mode = st.radio(
                    "Rescheduling mode",
                    [
                        "AI-powered (Gemini)",
                        "Priority-based (no AI)",
                    ],
                    key="reschedule_mode",
                )

                reschedule_clicked = st.form_submit_button(
                    "🔄 Preview New Schedule",
                    type="primary",
                    use_container_width=True,
                )

        if reschedule_clicked:
            if new_end <= new_start:
                st.error("End time must be later than start time.")

            else:
                dashboard_by_id = {
                    str(task["id"]): task
                    for task in st.session_state.tasks
                }

                completed_ids = set()

                # Prefer the live checkbox value, falling back
                # to the last saved history value.
                for item in original_schedule.get("scheduled", []):
                    activity_id = str(item["id"])
                    widget_key = (
                        f"schedule_{original_date}_{activity_id}"
                    )

                    live_status = st.session_state.get(
                        widget_key,
                        saved_statuses.get(activity_id, False),
                    )

                    if is_activity_completed(live_status):
                        completed_ids.add(activity_id)

                remaining_by_id = {}

                # Include unfinished scheduled items and items
                # that did not fit into the original timetable.
                original_items = (
                    original_schedule.get("scheduled", [])
                    + original_schedule.get("carry_forward", [])
                )

                for item in original_items:
                    activity_id = str(item["id"])

                    if activity_id in completed_ids:
                        continue

                    dashboard_task = dashboard_by_id.get(activity_id)

                    if dashboard_task:
                        if not parse_completed(
                            dashboard_task.get("completed", False)
                        ):
                            remaining_by_id[activity_id] = dashboard_task
                    else:
                        # Retain an unfinished historical activity
                        # even if its dashboard task was deleted.
                        remaining_by_id[activity_id] = {
                            "id": activity_id,
                            "name": item["name"],
                            "priority": item.get("priority", "Medium"),
                            "hours": item.get("hours", 1.0),
                            "completed": False,
                        }

                # Include other pending dashboard tasks, without
                # creating duplicate task IDs.
                for task in st.session_state.tasks:
                    task_id = str(task["id"])

                    if (
                        not parse_completed(task.get("completed", False))
                        and task_id not in completed_ids
                    ):
                        remaining_by_id[task_id] = task

                remaining = list(remaining_by_id.values())
                warning = None

                if (
                    reschedule_mode == "AI-powered (Gemini)"
                    and remaining
                ):
                    try:
                        with st.spinner(
                            "Gemini is organizing your remaining tasks..."
                        ):
                            ordered = order_tasks_with_ai(remaining)

                    except Exception as error:
                        ordered = sorted(
                            remaining,
                            key=lambda task: (
                                priority_order(task),
                                -duration(task),
                            ),
                        )
                        warning = (
                            "Gemini was unavailable, so priority-based "
                            "ordering was used. "
                            f"Details: {error}"
                        )

                else:
                    ordered = sorted(
                        remaining,
                        key=lambda task: (
                            priority_order(task),
                            -duration(task),
                        ),
                    )

                try:
                    scheduled, carry_forward = build_timetable(
                        ordered,
                        new_start,
                        new_end,
                        new_break,
                    )

                    st.session_state.rescheduled_schedule = {
                        "date": original_date,
                        "scheduled": scheduled,
                        "carry_forward": carry_forward,
                        "start": new_start.strftime("%I:%M %p"),
                        "end": new_end.strftime("%I:%M %p"),
                        "break_minutes": new_break,
                        "warning": warning,
                        "generated_at": datetime.now().isoformat(
                            timespec="minutes"
                        ),
                        "rescheduled": True,
                    }

                except Exception as error:
                    st.error(
                        f"Unable to create the new timetable: {error}"
                    )

        new_schedule = st.session_state.get("rescheduled_schedule")

        if new_schedule:
            st.divider()

            show_timetable(
                new_schedule,
                "🔄 Rescheduled Timetable Preview",
            )

            st.info(
                "This is a preview. Your current timetable and saved "
                "history remain unchanged until you apply this schedule."
            )

            if st.button(
                "✅ Use This Schedule for Daily Tracking",
                type="primary",
                key="use_rescheduled_schedule",
                use_container_width=True,
            ):
                st.session_state.daily_schedule = new_schedule

                # Reinitialize schedule checkboxes from saved history
                # when the replacement timetable is displayed.
                for item in new_schedule.get("scheduled", []):
                    activity_id = str(item["id"])
                    key = (
                        f"schedule_{new_schedule['date']}_"
                        f"{activity_id}"
                    )
                    st.session_state.pop(key, None)

                st.session_state.rescheduled_schedule = None
                st.session_state.navigation_page = "📅 Daily Scheduler"
                st.rerun()


# =========================================================
# END OF PART 3
# Part 4 adds AI Planner and Task Breakdown.
# =========================================================
# =========================================================
# 18. FOCUSED AI PLANNER PAGE
# =========================================================

elif selected_page == "🧠 AI Planner":

    st.subheader("✨ Turn a learning goal into a focused plan")

    st.write(
        "Describe what you want to achieve. For broad subjects, "
        "select a specific topic so Gemini can create a more "
        "relevant learning plan."
    )

    with st.container(border=True):

        planner_request = st.text_input(
            "What do you want to accomplish?",
            placeholder="Example: Prepare for DSA",
            key="planner_request",
        )

        broad_subject = (
            detect_broad_subject(planner_request)
            if planner_request.strip()
            else None
        )

        selected_topic = None
        custom_topic = ""

        if broad_subject:
            st.info(
                f"**{broad_subject}** is a broad subject. "
                "Choose a specific topic below."
            )

            selected_topic = st.selectbox(
                "Choose a specific topic",
                TOPIC_CATALOG[broad_subject],
                key="planner_topic",
            )

            if selected_topic == "Custom topic":
                custom_topic = st.text_input(
                    "Enter your custom topic",
                    placeholder="Example: Monotonic stacks",
                    key="planner_custom_topic",
                )

        elif planner_request.strip():
            st.caption(
                "Your request will be used as the topic for the plan."
            )

        col1, col2 = st.columns(2)

        with col1:
            planner_level = st.selectbox(
                "Skill level",
                ["Beginner", "Intermediate", "Advanced"],
                key="planner_level",
            )

        with col2:
            planner_goal = st.selectbox(
                "Goal",
                [
                    "Practice coding problems",
                    "Learn concepts",
                    "Prepare for an exam",
                    "Interview preparation",
                    "Revise concepts",
                ],
                key="planner_goal",
            )

        col1, col2 = st.columns(2)

        with col1:
            planner_priority = st.selectbox(
                "Priority",
                ["High", "Medium", "Low"],
                key="planner_priority",
            )

        with col2:
            planner_hours = st.selectbox(
                "Available hours",
                [0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0],
                index=3,
                key="planner_hours",
            )

        generate_plan = st.button(
            "✨ Generate Focused AI Plan",
            type="primary",
            use_container_width=True,
            key="generate_focused_plan",
        )

        if generate_plan:
            if not planner_request.strip():
                st.warning("Enter your learning goal first.")

            else:
                if broad_subject:
                    if selected_topic == "Custom topic":
                        topic = custom_topic.strip()
                    else:
                        topic = selected_topic or ""
                else:
                    topic = planner_request.strip()

                if not topic:
                    st.warning("Choose or enter a specific topic.")

                else:
                    prompt = f"""
You are TaskPilot AI, an expert learning planner.

Create a practical, focused learning plan.

Request: {planner_request}
Specific topic: {topic}
Skill level: {planner_level}
Goal: {planner_goal}
Priority: {planner_priority}
Available time: {planner_hours} hours

Include:
1. A clear learning objective.
2. Actionable steps in a logical order.
3. A time breakdown totaling exactly {planner_hours} hours.
4. A measurable checklist.
5. One productivity tip.
6. A small practice task or self-assessment.

Keep the plan realistic and focused on the selected topic.
Use Markdown headings, short paragraphs, and checklists.
Do not add unrelated topics.
"""

                    try:
                        with st.spinner(
                            "Gemini is creating your learning plan..."
                        ):
                            plan = gemini_text(prompt)

                        st.session_state.focused_ai_plan = plan
                        st.session_state.focused_plan_topic = topic
                        st.session_state.resolved_planner_topic = topic
                        st.session_state.saved_planner_request = (
                            planner_request.strip()
                        )
                        st.session_state.saved_planner_level = (
                            planner_level
                        )
                        st.session_state.saved_planner_goal = planner_goal
                        st.session_state.saved_planner_hours = (
                            float(planner_hours)
                        )
                        st.session_state.saved_planner_priority = (
                            planner_priority
                        )

                    except Exception as error:
                        st.error(
                            f"Unable to generate the plan: {error}"
                        )

    saved_plan = st.session_state.get("focused_ai_plan")

    if saved_plan:
        st.divider()

        with st.container(border=True):
            st.subheader("📘 Your Focused AI Plan")

            st.caption(
                "Topic: "
                f"{st.session_state.get('focused_plan_topic', '—')}"
            )

            st.markdown(saved_plan)

        st.caption(
            "Your generated plan remains available during this session."
        )


# =========================================================
# 19. TASK BREAKDOWN PAGE
# =========================================================

elif selected_page == "🧩 Task Breakdown":

    st.subheader("🧩 Break down an existing task")

    st.write(
        "Convert a large task into smaller, actionable steps. "
        "Review the generated subtasks before adding them."
    )

    tasks = st.session_state.tasks

    if not tasks:
        st.info(
            "You don't have any dashboard tasks yet. "
            "Open My Tasks to create one first."
        )

    else:
        task_options = {
            (
                f"{task['name']} — {task['priority']} — "
                f"{str(task['id'])[:6]}"
            ): task
            for task in tasks
        }

        with st.container(border=True):

            selected_label = st.selectbox(
                "Choose a task",
                list(task_options.keys()),
                key="existing_task_selection",
            )

            selected_task = task_options[selected_label]

            col1, col2 = st.columns(2)

            with col1:
                breakdown_level = st.selectbox(
                    "Skill level",
                    ["Beginner", "Intermediate", "Advanced"],
                    key="breakdown_level",
                )

            with col2:
                breakdown_goal = st.selectbox(
                    "Goal",
                    [
                        "Complete the task",
                        "Learn concepts",
                        "Practice coding problems",
                        "Prepare for an exam",
                        "Interview preparation",
                    ],
                    key="breakdown_goal",
                )

            if st.button(
                "🧠 Break Down Selected Task",
                type="primary",
                use_container_width=True,
                key="breakdown_existing_task",
            ):
                try:
                    with st.spinner(
                        "Gemini is breaking down your task..."
                    ):
                        subtasks = generate_subtasks(
                            selected_task["name"],
                            selected_task["name"],
                            breakdown_level,
                            breakdown_goal,
                            duration(selected_task),
                        )

                    st.session_state.existing_subtasks = subtasks
                    st.session_state.existing_parent_name = (
                        selected_task["name"]
                    )

                except Exception as error:
                    st.error(
                        f"Could not generate subtasks: {error}"
                    )

        subtask_review(
            "existing_subtasks",
            st.session_state.get("existing_parent_name", ""),
            "existing_subtask_review",
        )

    st.divider()

    st.subheader("✨ Turn Your AI Plan into Tasks")

    saved_plan = st.session_state.get("focused_ai_plan")

    if not saved_plan:
        st.info(
            "Generate a plan in the AI Planner first. "
            "It will then be available here."
        )

    else:
        st.caption(
            "Generate actionable dashboard tasks using your saved "
            "planner topic, skill level, goal, and available time."
        )

        st.markdown(
            "**Current plan topic:** "
            f"{st.session_state.get('focused_plan_topic', '—')}"
        )

        if st.button(
            "🧩 Generate Subtasks from My Planner",
            type="primary",
            use_container_width=True,
            key="generate_planner_subtasks",
        ):
            topic = st.session_state.get(
                "resolved_planner_topic", ""
            ).strip()

            planner_request = st.session_state.get(
                "saved_planner_request", topic
            )
            planner_level = st.session_state.get(
                "saved_planner_level", "Beginner"
            )
            planner_goal = st.session_state.get(
                "saved_planner_goal", "Learn concepts"
            )
            planner_hours = st.session_state.get(
                "saved_planner_hours", 2.0
            )

            if not topic:
                st.warning(
                    "Generate a new plan in the AI Planner first."
                )

            else:
                try:
                    with st.spinner(
                        "Gemini is generating actionable subtasks..."
                    ):
                        subtasks = generate_subtasks(
                            planner_request,
                            topic,
                            planner_level,
                            planner_goal,
                            planner_hours,
                        )

                    st.session_state.planner_subtasks = subtasks
                    st.session_state.planner_parent_name = (
                        planner_request or topic
                    )

                except Exception as error:
                    st.error(
                        f"Could not generate planner subtasks: {error}"
                    )

        subtask_review(
            "planner_subtasks",
            st.session_state.get(
                "planner_parent_name", "Planner task"
            ),
            "planner_subtask_review",
        )


# =========================================================
# END OF PART 4
# Part 5 adds Daily History and Monthly Insights.
# =========================================================
# =========================================================
# 20. DAILY HISTORY PAGE
# =========================================================

elif selected_page == "📚 Daily History":

    st.subheader("📚 Your Daily Completion History")

    st.write(
        "Review the activities you tracked and saved on previous days."
    )

    history = st.session_state.schedule_history

    if not history:
        st.info(
            "No saved history yet. Generate a schedule, mark activities "
            "as completed or pending, and select Save Daily Completion."
        )

    else:
        history_rows = []

        for recorded_date, record in sorted(
            history.items(),
            reverse=True,
        ):
            if not isinstance(record, dict):
                continue

            activities = get_history_activities(record)

            completed_count = sum(
                1
                for status in activities.values()
                if is_activity_completed(status)
            )

            tracked_count = len(activities)
            pending_count = tracked_count - completed_count

            rate = (
                completed_count / tracked_count * 100
                if tracked_count
                else 0.0
            )

            history_rows.append({
                "Date": str(recorded_date),
                "Activities Tracked": tracked_count,
                "Completed": completed_count,
                "Pending": pending_count,
                "Completion Rate": f"{rate:.1f}%",
                "Last Saved": record.get("updated_at") or "—",
            })

        if history_rows:
            history_df = pd.DataFrame(history_rows)

            total_days = len(history_rows)
            total_tracked = sum(
                row["Activities Tracked"] for row in history_rows
            )
            total_completed = sum(
                row["Completed"] for row in history_rows
            )
            total_pending = total_tracked - total_completed

            overall_rate = (
                total_completed / total_tracked
                if total_tracked
                else 0.0
            )

            c1, c2, c3, c4 = st.columns(4)

            c1.metric("Days Recorded", total_days)
            c2.metric("Activities Tracked", total_tracked)
            c3.metric("Activities Completed", total_completed)
            c4.metric("Completion Rate", f"{overall_rate:.0%}")

            st.progress(overall_rate)

            st.divider()
            st.subheader("Saved Daily Records")

            st.dataframe(
                history_df,
                use_container_width=True,
                hide_index=True,
            )

            st.download_button(
                "📥 Download Daily History CSV",
                data=history_df.to_csv(
                    index=False
                ).encode("utf-8"),
                file_name="taskpilot_daily_history.csv",
                mime="text/csv",
                key="download_daily_history",
                use_container_width=True,
            )

            st.caption(
                "History is calculated from saved schedule activities. "
                "It is separate from dashboard task completion."
            )

        else:
            st.info("No valid daily activity records were found.")


# =========================================================
# 21. MONTHLY INSIGHTS PAGE
# =========================================================

elif selected_page == "📊 Monthly Insights":

    st.subheader("📊 Monthly Productivity Insights")

    st.write(
        "Analyze your saved daily schedule completion and export "
        "a monthly productivity report."
    )

    st.info(
        "These insights count saved scheduled activities. They do not "
        "count the completed tasks displayed on your Dashboard."
    )

    history = st.session_state.schedule_history

    available_months = sorted(
        {
            str(recorded_date)[:7]
            for recorded_date in history
            if len(str(recorded_date)) >= 7
        },
        reverse=True,
    )

    this_month = date.today().strftime("%Y-%m")

    if this_month not in available_months:
        available_months.insert(0, this_month)

    selected_month = st.selectbox(
        "📅 Select month",
        available_months,
        key="monthly_insights_month",
    )

    monthly_records = []

    for recorded_date, record in history.items():

        if not str(recorded_date).startswith(selected_month):
            continue

        if not isinstance(record, dict):
            continue

        activities = get_history_activities(record)

        completed_count = sum(
            1
            for value in activities.values()
            if is_activity_completed(value)
        )

        tracked_count = len(activities)
        pending_count = tracked_count - completed_count

        completion_rate = (
            completed_count / tracked_count
            if tracked_count
            else 0.0
        )

        monthly_records.append({
            "Date": str(recorded_date),
            "Scheduled": tracked_count,
            "Completed": completed_count,
            "Pending": pending_count,
            "Completion Rate": completion_rate,
            "Activities": activities,
        })

    monthly_records.sort(key=lambda row: row["Date"])

    if not monthly_records:
        with st.container(border=True):
            st.subheader("🌱 Your monthly report will appear here")

            st.write(
                f"There are no saved schedule records for "
                f"{selected_month}."
            )

            st.markdown(
                """
                To build your report:

                1. Open **Daily Scheduler**.
                2. Generate a timetable.
                3. Mark the activities you actually complete.
                4. Select **Save Daily Completion**.
                """
            )

            st.caption(
                "No completed activities are assumed when history "
                "is absent."
            )

    else:
        scheduled_total = sum(
            row["Scheduled"] for row in monthly_records
        )
        completed_total = sum(
            row["Completed"] for row in monthly_records
        )
        pending_total = sum(
            row["Pending"] for row in monthly_records
        )

        monthly_rate = (
            completed_total / scheduled_total
            if scheduled_total
            else 0.0
        )

        active_days = len(monthly_records)

        best_day = max(
            monthly_records,
            key=lambda row: (
                row["Completion Rate"],
                row["Completed"],
            ),
        )

        # -------------------------------------------------
        # Monthly KPI cards
        # -------------------------------------------------

        c1, c2, c3, c4 = st.columns(4)

        c1.metric("Activities Scheduled", scheduled_total)
        c2.metric("Activities Completed", completed_total)
        c3.metric("Activities Pending", pending_total)
        c4.metric("Monthly Completion", f"{monthly_rate:.0%}")

        st.progress(monthly_rate)

        st.caption(
            f"You have saved activity records for "
            f"{active_days} day(s) in {selected_month}."
        )

        st.divider()

        # -------------------------------------------------
        # Daily completion trend
        # -------------------------------------------------

        st.subheader("📈 Daily Completion Trend")

        trend_df = pd.DataFrame([
            {
                "Date": row["Date"],
                "Completed": row["Completed"],
                "Pending": row["Pending"],
            }
            for row in monthly_records
        ])

        trend_df = trend_df.set_index("Date")

        st.line_chart(
            trend_df[["Completed", "Pending"]],
            use_container_width=True,
        )

        st.caption(
            "Each point represents the saved activity counts "
            "for a recorded day."
        )

        st.divider()

        # -------------------------------------------------
        # Best day and priority breakdown
        # -------------------------------------------------

        st.subheader("🏆 Monthly Highlights")

        highlight1, highlight2 = st.columns(2)

        with highlight1:
            with st.container(border=True):
                st.markdown("**Best recorded completion day**")
                st.metric("Date", best_day["Date"])
                st.metric(
                    "Completion rate",
                    f"{best_day['Completion Rate']:.0%}",
                )
                st.caption(
                    f"{best_day['Completed']} of "
                    f"{best_day['Scheduled']} activities completed."
                )

        priority_counts = {
            "High": 0,
            "Medium": 0,
            "Low": 0,
        }

        for row in monthly_records:
            for activity in row["Activities"].values():

                if not isinstance(activity, dict):
                    continue

                if not is_activity_completed(activity):
                    continue

                priority = activity.get("priority", "Medium")

                if priority in priority_counts:
                    priority_counts[priority] += 1

        with highlight2:
            with st.container(border=True):
                st.markdown("**Completed activities by priority**")

                for priority, count in priority_counts.items():
                    st.write(f"**{priority}:** {count}")

                st.caption(
                    "Priority breakdown includes completed activities "
                    "whose saved records contain priority information."
                )

        st.divider()

        # -------------------------------------------------
        # Daily summary table
        # -------------------------------------------------

        st.subheader("📅 Monthly Daily Summary")

        summary_df = pd.DataFrame([
            {
                "Date": row["Date"],
                "Scheduled": row["Scheduled"],
                "Completed": row["Completed"],
                "Pending": row["Pending"],
                "Completion Rate": (
                    f"{row['Completion Rate']:.1%}"
                ),
            }
            for row in monthly_records
        ])

        st.dataframe(
            summary_df,
            use_container_width=True,
            hide_index=True,
        )

        st.download_button(
            "📥 Download Monthly Insights CSV",
            data=summary_df.to_csv(
                index=False
            ).encode("utf-8"),
            file_name=f"taskpilot_insights_{selected_month}.csv",
            mime="text/csv",
            key="download_monthly_insights",
            use_container_width=True,
        )


# =========================================================
# 22. SHARED FOOTER
# =========================================================

st.divider()

footer_left, footer_right = st.columns(2)

with footer_left:
    st.caption("🤖 TaskPilot AI · Your personal productivity assistant")

with footer_right:
    st.caption(
        f"Today: {date.today().strftime('%d %B %Y')}"
    )


# =========================================================
# END OF PART 5 — APP COMPLETE
# =========================================================