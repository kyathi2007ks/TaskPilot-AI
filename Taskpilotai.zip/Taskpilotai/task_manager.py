
import json
from pathlib import Path

# Store tasks in a JSON file beside this Python file.
DATA_FILE = Path(__file__).resolve().parent / "tasks.json"


def load_tasks():
    """Load saved tasks from JSON."""
    if not DATA_FILE.exists():
        return []

    try:
        with DATA_FILE.open("r", encoding="utf-8") as file:
            tasks = json.load(file)

        if not isinstance(tasks, list):
            raise ValueError("Task data must be a list.")

        return tasks

    except (json.JSONDecodeError, ValueError) as error:
        raise ValueError(
            f"Could not read task data from {DATA_FILE.name}. "
            "Restore a valid backup before continuing."
        ) from error


def save_tasks(tasks):
    """Save tasks safely to JSON."""
    temporary_file = DATA_FILE.with_suffix(".tmp")

    try:
        with temporary_file.open("w", encoding="utf-8") as file:
            json.dump(tasks, file, indent=4, ensure_ascii=False)

        # Replace the old file only after the new data is written.
        temporary_file.replace(DATA_FILE)

    finally:
        if temporary_file.exists():
            temporary_file.unlink()
