
import os
from dotenv import load_dotenv
from google import genai

load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    print("ERROR: GEMINI_API_KEY not found in .env")
else:
    client = genai.Client(api_key=api_key)

    models = [
        "gemini-3.8-flash",
        "gemini-3.5-flash-lite",
    ]

    for model in models:
        try:
            print(f"\nTesting {model}...")
            response = client.models.generate_content(
                model=model,
                contents="Reply with exactly: Gemini connection successful"
            )
            print("SUCCESS:", model)
            print(response.text)
            break
        except Exception as error:
            print("FAILED:", model)
            print(str(error))
